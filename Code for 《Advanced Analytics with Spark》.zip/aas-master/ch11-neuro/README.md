The data in the `fish-long/` subdirectory come from version 0.4.1 of the
Thunder project, which is Apache v2 licensed.
